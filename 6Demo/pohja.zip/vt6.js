"use strict";

class App extends React.Component {
    constructor(props) {
      super(props);
      this.kisa = data.kisatiedot;
      this.rastit = data.rastit;
      this.state = { 
        "joukkueet" : data.joukkueet
      };
    }
    render () {
      return <div>
        </div>;
    }
}


ReactDOM.render(
    <App />,
  document.getElementById('root')

);
